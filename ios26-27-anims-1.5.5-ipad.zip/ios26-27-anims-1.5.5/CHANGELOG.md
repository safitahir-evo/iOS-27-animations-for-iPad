# История изменений

## 1.5.5-ipad4 (iPad build)

- Landscape genie now follows the real SpringBoard zoom (container progress is measured per orientation) instead of
  running on its own clock, which caused the oversized, blurry icon flashing over the app.
- iPad fail-safe: if the zoom geometry is not recognised (Stage Manager window, Split View), the genie is dropped
  after 0.15s and the stock animation finishes cleanly.
- Sharper scaled icon layers (texture-size cap instead of a fixed 4x).
- Gesture close tuning now applies on iPad; fly-in distances scale with screen size.
- Small capped diagnostics log on iPad: /var/mobile/Library/Logs/27anims-ipad.log

## 1.5.5 / Reborn 1.0.0 Beta 2

- fixed crash on ios 15
- fixed notification center cleanup on ios 15
- tested on iphone 13 pro max ios 15.0.2

## 1.5.4

- Иконка при закрытии садится точно на место иконки SnowBoard и больше не дёргается, когда её подменяет иконка рабочего стола.
- Летящая иконка больше не мыльная: при масштабе SnowBoard она рисуется в своём настоящем размере.
- При открытии иконка гнётся вместе с окном и не обрезается квадратом.
- Отскок при свайпе домой задаётся каждому закрытию напрямую и не зависит от состояния настроек SpringBoard.

## 1.5.3

- Крупные иконки (масштаб SnowBoard, темы) больше не обрезаются квадратом при закрытии и гнутся вместе с окном.
- Отскок при свайпе домой больше не пропадает до респринга.
- Новые настройки на английском и русском: на главной включение, скорость, шторка; остальное в «Дополнительно».
- После установки твик выключен, включается в Настройках.

## 1.5.2 — 2026-11-07

- При изменённом масштабе иконок SnowBoard сетка джина не накладывается на слой с иконкой.

## 1.5.1 — 2026-11-07

- Настройки: скорость открытия и закрытия, сила джина и разлёта иконок, «капля», отскок при свайпе,
  прозрачная шторка, размытие при разлёте, замедление твика и всех анимаций, сброс, респринг.
- Исправлены быстрые повторные переходы, запуск джина и восстановление иконок после анимации шторки.

## 1.5.0 — 2026-10-28

- Страница в Настройках «iOS 27 Animations» (нужен PreferenceLoader).
- Отдельные переключатели: «Открытие и закрытие» (`AppAnimations`), «Эффект джина» (`Genie`),
  «Анимация шторки» (`IconFlyIn`). Общий выключатель `Enabled` остался.
- Настройки применяются без респринга (уведомление `com.bazik1337.ios2627anims/changed`).

## 1.4.7 — 2026-10-10

- Пакет переименован в «iOS 27 Animations».

## 1.4.6 Beta 1 — 2026-10-07

- Минимальная версия iOS снижена с 16.0 до 15.0.
