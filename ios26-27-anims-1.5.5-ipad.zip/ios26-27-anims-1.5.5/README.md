# iOS 27 Animations

Анимации iOS 27 для iOS 15–16 (rootless и rootful, arm64/arm64e): открытие и закрытие приложений с эффектом джина, разлёт иконок при закрытии шторки.

<p>
<img src="docs/screenshots/close.jpg" width="100%">
</p>

## Установка

1. Sileo → Источники → «+» → `https://repo.ba31k.com/`
2. Установи **iOS 27 Animations**.
3. Настройки → iOS 27 Animations → **Включено**.

Или скачай `.deb` из [Releases](https://github.com/ba31k/ios26-27-anims/releases).

<p>
<img src="docs/screenshots/settings.png" width="260">
<img src="docs/screenshots/advanced.png" width="260">
</p>

## Сурсы

- `iOS27Animations` 1.5.5
- `iOS27AnimationsReborn` 1.0.0 Beta 2

```sh
make -C iOS27Animations package FINALPACKAGE=1
make -C iOS27AnimationsReborn package FINALPACKAGE=1
```

Для rootful добавь `THEOS_PACKAGE_SCHEME=`.

Обновления — в канале [@ba31k_tweaks](https://t.me/ba31k_tweaks). Автор — [@bazik1337](https://t.me/bazik1337).
